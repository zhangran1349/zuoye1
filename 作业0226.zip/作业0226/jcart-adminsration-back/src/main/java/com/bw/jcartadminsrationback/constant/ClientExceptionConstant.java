package com.bw.jcartadminsrationback.constant;

public class ClientExceptionConstant {
    public static final String IMAGE_INVALID_ERRCODE = "0001";
    public static final String IMAGE_INVALID_ERRMSG = "image is not jpg or png";
}
