package com.bw.jcartadminsrationback.controller;

import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/administrator")
public class AdministratorController {

    @GetMapping("/login")
    public String loagin(AdministratorLoginInDTO administratorLoginInDTOn){
        return null;
    }

    public AdministratorGetProfileOutDTO getProfile(Integer administratorid){
        return null;
    }

    @PostMapping("/updateProfile")
    public void uodateProfile(@RequestParam AdministratorUpdateProfileInDTO administratorUpdateProfileInDTO){

    }
}
