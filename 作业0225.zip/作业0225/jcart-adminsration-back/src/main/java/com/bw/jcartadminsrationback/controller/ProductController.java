package com.bw.jcartadminsrationback.controller;

import com.bw.jcartadminsrationback.dto.in.ProductCreateInDTO;
import com.bw.jcartadminsrationback.dto.in.ProductSearchInDTO;
import com.bw.jcartadminsrationback.dto.in.ProductUpdateInDTO;
import com.bw.jcartadminsrationback.dto.out.PageOutDTO;
import com.bw.jcartadminsrationback.dto.out.ProductListOutDTO;
import com.bw.jcartadminsrationback.dto.out.ProductShowOutDTO;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/product")
public class ProductController {

    @GetMapping("/search")
    public PageOutDTO<ProductListOutDTO> search(ProductSearchInDTO productSearchInDTO,
                                                @RequestParam Integer pageNum){
        return null;
    }

    @GetMapping("/getById")
    public ProductShowOutDTO getById(@RequestParam Integer productId){
        return null;
    }

    @PostMapping("/create")
    public Integer create(@RequestBody ProductCreateInDTO productCreateInDTO){
        return null;
    }

    @PostMapping("/update")
    public void update(@RequestBody ProductUpdateInDTO productUpdateInDTO){

    }

}
